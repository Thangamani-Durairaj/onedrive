﻿

using System.Configuration;

namespace Cat.Terra.Jobs.WebAPI.Business
{
    public class Configurations
    {


        public static string Connectionstring = ConfigurationManager.ConnectionStrings["StorageAccount"].ConnectionString;


    }
}
