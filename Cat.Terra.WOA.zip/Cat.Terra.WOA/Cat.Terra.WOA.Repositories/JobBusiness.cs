﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cat.Terra.WOA.DA;
using Cat.Terra.WOA.Entities;

namespace Cat.Terra.WOA.Business
{
    public class JobBusiness : IJobBusiness
    {
        private IJobsDA _JobsDA;

        public JobBusiness(IJobsDA JobsDA)
        {
            _JobsDA = JobsDA;
        }

        public async Task<IEnumerable<Job>> GetJobsAsync(JobRequest request)
        {
           return await _JobsDA.GetJobsAsync(request);
        }
    }
}
