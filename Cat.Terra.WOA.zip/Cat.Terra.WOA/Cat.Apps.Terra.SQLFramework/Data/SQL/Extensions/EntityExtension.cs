﻿using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Attributes;
using System;
using System.Linq.Expressions;
using System.Reflection;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL.Extensions
{
    public static class EntityExtension
    {
        public static string TableName<T>(this T entity) where T : IEntity
        {
            return ((TableNameAttribute)typeof(T).GetCustomAttribute(typeof(TableNameAttribute)))?.Name;
        }

        public static string SchemaName<T>(this T entity) where T : IEntity
        {
            return ((SchemaAttribute)typeof(T).GetCustomAttribute(typeof(SchemaAttribute)))?.Name;
        }

        public static string TableFullName<T>(this T entity) where T : IEntity
        {
            string schemaName = ((SchemaAttribute)typeof(T).GetCustomAttribute(typeof(SchemaAttribute)))?.Name;
            string tableName = ((TableNameAttribute)typeof(T).GetCustomAttribute(typeof(TableNameAttribute)))?.Name;
            return !string.IsNullOrEmpty(schemaName) && !string.IsNullOrEmpty(tableName) ? " [" + schemaName + "].[" + tableName + "] " :
                !string.IsNullOrEmpty(tableName) ? tableName : null;
        }

        public static string Column<T, K>(this T entity, Expression<Func<T, K>> expression) where T : IEntity
        {
            return ((MapToAttribute)((MemberExpression)expression.Body).Member.GetCustomAttribute(typeof(MapToAttribute)))?.DatabaseColumn ?? ((MemberExpression)expression.Body).Member.Name;
        }

        public static K GetQuery<T1, K>(this Func<T1, K> query)
            where T1 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>());
        }

        public static K GetQuery<T1, T2, K>(this Func<T1, T2, K> query)
            where T1 : IEntity
            where T2 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>());
        }

        public static K GetQuery<T1, T2, T3, K>(this Func<T1, T2, T3, K> query)
            where T1 : IEntity
            where T2 : IEntity
            where T3 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>());
        }

        public static K GetQuery<T1, T2, T3, T4, K>(this Func<T1, T2, T3, T4, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(), Activator.CreateInstance<T4>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, K>(this Func<T1, T2, T3, T4, T5, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, K>(this Func<T1, T2, T3, T4, T5, T6, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, K>(this Func<T1, T2, T3, T4, T5, T6, T7, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(), Activator.CreateInstance<T7>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(), Activator.CreateInstance<T10>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(), 
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(), Activator.CreateInstance<T13>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
           where T14 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(), 
                Activator.CreateInstance<T13>(), Activator.CreateInstance<T14>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
           where T14 : IEntity
           where T15 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(),
                Activator.CreateInstance<T13>(), Activator.CreateInstance<T14>(), Activator.CreateInstance<T15>());
        }

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
           where T14 : IEntity
           where T15 : IEntity
           where T16 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(),
                Activator.CreateInstance<T13>(), Activator.CreateInstance<T14>(), Activator.CreateInstance<T15>(), Activator.CreateInstance<T16>());
        }

        public delegate TResult Func<in T1, in T2, in T3, in T4, in T5, in T6, in T7, in T8, in T9, in T10, in T11, in T12, in T13, in T14, in T15, in T16, in T17, out TResult>(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16, T17 arg17);

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
           where T14 : IEntity
           where T15 : IEntity
           where T16 : IEntity
           where T17 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(),
                Activator.CreateInstance<T13>(), Activator.CreateInstance<T14>(), Activator.CreateInstance<T15>(),
                Activator.CreateInstance<T16>(), Activator.CreateInstance<T17>());
        }

        public delegate TResult Func<in T1, in T2, in T3, in T4, in T5, in T6, in T7, in T8, in T9, in T10, in T11, in T12, in T13, in T14, in T15, in T16, in T17, in T18, out TResult>(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16, T17 arg17, T18 arg18);

        public static K GetQuery<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, K>(this Func<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, K> query)
           where T1 : IEntity
           where T2 : IEntity
           where T3 : IEntity
           where T4 : IEntity
           where T5 : IEntity
           where T6 : IEntity
           where T7 : IEntity
           where T8 : IEntity
           where T9 : IEntity
           where T10 : IEntity
           where T11 : IEntity
           where T12 : IEntity
           where T13 : IEntity
           where T14 : IEntity
           where T15 : IEntity
           where T16 : IEntity
           where T17 : IEntity
           where T18 : IEntity
        {
            return query.Invoke(Activator.CreateInstance<T1>(), Activator.CreateInstance<T2>(), Activator.CreateInstance<T3>(),
                Activator.CreateInstance<T4>(), Activator.CreateInstance<T5>(), Activator.CreateInstance<T6>(),
                Activator.CreateInstance<T7>(), Activator.CreateInstance<T8>(), Activator.CreateInstance<T9>(),
                Activator.CreateInstance<T10>(), Activator.CreateInstance<T11>(), Activator.CreateInstance<T12>(),
                Activator.CreateInstance<T13>(), Activator.CreateInstance<T14>(), Activator.CreateInstance<T15>(),
                Activator.CreateInstance<T16>(), Activator.CreateInstance<T17>(), Activator.CreateInstance<T18>());
        }
    }
}
