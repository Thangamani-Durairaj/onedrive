﻿using Dapper.Extensions.Linq.Core.Sessions;
using Dapper.Extensions.Linq.Core.Sql;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    public abstract class IDbConnectionBuilder : IConnectionStringProvider
    {
        public abstract ISqlDialect GetDBDialect();
        public abstract string GetDBConnectionString();

        string IConnectionStringProvider.ConnectionString(string connectionStringName)
        {
            return GetDBConnectionString();
        }
    }
}
