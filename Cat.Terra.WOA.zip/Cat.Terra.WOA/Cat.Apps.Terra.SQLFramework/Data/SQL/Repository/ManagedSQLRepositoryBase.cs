﻿using Castle.Windsor;
using Dapper;
using Dapper.Extensions.Linq.CastleWindsor;
using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Attributes;
using Dapper.Extensions.Linq.Core.Configuration;
using Dapper.Extensions.Linq.Core.Enums;
using Dapper.Extensions.Linq.Core.Logging;
using Dapper.Extensions.Linq.Core.Mapper;
using Dapper.Extensions.Linq.Core.Predicates;
using Dapper.Extensions.Linq.Core.Sessions;
using Dapper.Extensions.Linq.Core.Sql;
using Dapper.Extensions.Linq.Predicates;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Transactions;
using Cat.Apps.Terra.AppFramework;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    public abstract class ManagedSQLRepositoryBase<TRepository, T, S, K> : IDisposable
        where TRepository : ManagedSQLRepositoryBase<TRepository, T, S, K>
        where T : class, IEntity, new()
        where S : IDbConnectionBuilder, new()
    {
        private static Dictionary<string, DapperCustomSessionContext> dbSessions = new Dictionary<string, DapperCustomSessionContext>();
        private static Dictionary<string, DapperCustomSessionContext> dbTransactionSessions = new Dictionary<string, DapperCustomSessionContext>();
        private string m_TableName;
        private S DbHelper;
        private ISqlDialect DbDialect;
        private DapperConfiguration config;
        private DapperCustomRepository<T> repository;
        private WindsorContainer windsorContainer;
        private static readonly ILog Log = LogManager.GetLogger(typeof(TRepository));
        private string connectionString;

        #region Internal Kung Fu
        private string m_TableMessage
        {
            get { return "Table " + m_TableName + ": "; }
        }

        private string GetCurrentCatRectId()
        {
            //if (ClaimsPrincipal.Current != null && ClaimsPrincipal.Current.Identities != null && ClaimsPrincipal.Current.Identities.Count() > 0)
            //{
            //    return ClaimsPrincipal.Current.Identities.Where(x => x.AuthenticationType == "Bearer").SingleOrDefault()?.Claims.Where(c => c.Type == ApplicationClaimTypes.CATREC_ID).Select(x => x.Value).FirstOrDefault();
            //}
            //else
            //{
                return Process.GetCurrentProcess().ProcessName.Replace(".vshost", "");
            //}
        }

        private IDbConnection GetConnection()
        {
            return repository.GetConnection();
        }

        private ISqlGenerator GetSqlGenerator()
        {
            return repository.GetSqlGenerator();
        }

        private void EnsureConfiguration()
        {
            windsorContainer = new WindsorContainer();
            config = (DapperConfiguration)DapperConfiguration
                .Use()
                .UseClassMapper(typeof(AutoClassMapper<>))
                .UseContainer<CustomContainer>(c => { })
                .UseSqlDialect(DbDialect)
                .FromAssemblyContaining(typeof(T))
                .UsingConnectionProvider<S>("__Default");
            config.Build();
        }

        private void EnsureRepository()
        {
            repository = new DapperCustomRepository<T>(GetOrCreateSessionContext<T>());
        }

        private string GetIdentifier()
        {
            if (Transaction.Current != null)
            {
                return Transaction.Current.TransactionInformation.LocalIdentifier + "-" + connectionString;
            }
            else
            {
                return connectionString;
            }
        }

        private DapperCustomSessionContext GetOrCreateSessionContext<E>() where E : class, IEntity
        {
            IDictionary<string, DapperCustomSessionContext> dapperSessions = dbSessions;
            string identifier = GetIdentifier();
            try
            {
                if (Transaction.Current != null)
                {
                    dapperSessions = dbTransactionSessions;
                    Transaction.Current.TransactionCompleted += CurrentTransactionCompleted;
                }
                if (dapperSessions.ContainsKey(identifier) && dapperSessions[identifier].BoundedSessions.Count() > 0
                    && dapperSessions[identifier].GetSession<E>() != null && dapperSessions[identifier].GetSession<E>().Connection != null
                    && dapperSessions[identifier].GetSession<E>().Connection.State == ConnectionState.Open)
                {
                    return dapperSessions[identifier];
                }
                else
                {
                    return CreateSessionContext(dapperSessions);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex);
                return CreateSessionContext(dapperSessions);
            }
        }

        private DapperCustomSessionContext CreateSessionContext(IDictionary<string, DapperCustomSessionContext> dapperSessions)
        {
            string identifier = GetIdentifier();
            DapperCustomSessionContext sessionContext = new DapperCustomSessionContext(new DapperSessionFactory(config), config);
            if (dapperSessions.ContainsKey(identifier))
            {
                dapperSessions[identifier] = sessionContext;
            }
            else
            {
                dapperSessions.Add(identifier, sessionContext);
            }
            return sessionContext;
        }

        private void CurrentTransactionCompleted(object sender, TransactionEventArgs e)
        {
            try
            {
                List<KeyValuePair<string, DapperCustomSessionContext>> dapperSessions = dbTransactionSessions.Where(x => x.Key.StartsWith(e.Transaction.TransactionInformation.LocalIdentifier)).ToList();
                dapperSessions.ForEach(x =>
                {
                    dbTransactionSessions.Remove(x.Key);
                    if (x.Value.GetSession<T>() != null && x.Value.GetSession<T>().Connection.State == ConnectionState.Open)
                    {
                        x.Value.GetSession<T>().Connection.Close();
                        x.Value.GetSession<T>().Connection.Dispose();
                    }
                });
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex);
            }
        }

        private void EnsureTable()
        {
            if (m_TableName.IsNullOrEmpty())
            {
                string tableName = GetTableName();
                if (!tableName.IsNullOrEmpty())
                {
                    HydrateTable(tableName);
                }
            }
        }

        private void EnsureDbHelper()
        {
            DbHelper = new S();
            DbDialect = DbHelper.GetDBDialect();
            connectionString = DbHelper.GetDBConnectionString();
        }

        private void EnsureConfig()
        {
            if (DbHelper == null)
            {
                EnsureDbHelper();
            }
            if (config == null)
            {
                EnsureConfiguration();
                EnsureRepository();
                EnsureTable();
            }
            else
            {
                EnsureRepository();
            }
        }

        private void ReConfig(T entity)
        {
            AutoClassMapper<T> entityMap = ((AutoClassMapper<T>)config.GetMap<T>());
            FieldInfo schemaField = entity.GetType().GetField("SchemaName", BindingFlags.Public | BindingFlags.Instance);
            if (schemaField != null && entityMap != null)
            {
                entityMap.SetSchema(schemaField.GetValue(entity)?.ToString());
            }
            FieldInfo tableNameField = entity.GetType().GetField("TableName", BindingFlags.Public | BindingFlags.Instance);
            if (tableNameField != null && entityMap != null)
            {
                entityMap.Table(tableNameField.GetValue(entity)?.ToString());
            }
        }

        private void HydrateTable(string tableName)
        {
            if (m_TableName.IsNullOrEmpty())
            {
                m_TableName = tableName;
            }
            else
            {
                if (m_TableName != tableName)
                {
                    throw new InvalidOperationException("Current table name is '" + m_TableName +
                        "' but it changed to '" + tableName + ".'  It must remain constant.");
                }
            }
        }

        private void PrepareForInsert(T entity)
        {
            if (entity.GetType().GetProperty("CreatedDate") != null)
            {
                entity.GetType().GetProperty("CreatedDate").SetValue(entity, DateTime.UtcNow);
            }
            if (entity.GetType().GetProperty("CreatedBy") != null)
            {
                entity.GetType().GetProperty("CreatedBy").SetValue(entity, GetCurrentCatRectId());
            }
        }

        private void PrepareForUpdate(T entity)
        {
            if (entity.GetType().GetProperty("LastModifiedDate") != null)
            {
                entity.GetType().GetProperty("LastModifiedDate").SetValue(entity, DateTime.UtcNow);
            }
            if (entity.GetType().GetProperty("LastModifiedBy") != null)
            {
                entity.GetType().GetProperty("LastModifiedBy").SetValue(entity, GetCurrentCatRectId());
            }
        }

        private K PerformInsert(T entity)
        {
            dynamic identity = repository.Insert(entity);
            try
            {
                return (K)Convert.ChangeType(identity, typeof(K));
            }
            catch (InvalidCastException)
            {
                return (K)Convert.ChangeType(0, typeof(K));
            }
        }

        private void PerformInserts(IEnumerable<T> entities)
        {
            repository.Insert(entities);
        }

        private bool PerformUpdate(T entity)
        {
            return repository.Update(entity);
        }

        private bool PerformDelete(T entity)
        {
            return repository.Delete(entity);
        }

        private IPredicate GetKeyPredicate(IClassMapper classMap)
        {
            List<IPropertyMap> whereFields = classMap.Properties
                .Where(p => p.KeyType != KeyType.NotAKey)
                .ToList();

            if (!whereFields.Any())
                throw new ArgumentException("At least one Key column must be defined.");

            IList<IPredicate> predicates = whereFields
                .Select(field => new FieldPredicate<T>
                {
                    Not = false,
                    Operator = Operator.Eq,
                    PropertyName = field.Name,
                    Value = "@" + field.Name
                })
                .Cast<IPredicate>()
                .ToList();

            return predicates.Count == 1
                       ? predicates[0]
                       : new PredicateGroup
                       {
                           Operator = GroupOperator.And,
                           Predicates = predicates
                       };
        }
        #endregion

        protected string GetTableName(Type type = null)
        {
            if (type == null)
            {
                type = typeof(T);
            }
            if (type.GetCustomAttribute(typeof(TableNameAttribute)) != null)
            {
                return ((TableNameAttribute)type.GetCustomAttribute(typeof(TableNameAttribute))).Name;
            }
            else
            {
                return null;
            }
        }

        protected string GetSchemaName(Type type = null)
        {
            if (type == null)
            {
                type = typeof(T);
            }
            if (type.GetCustomAttribute(typeof(SchemaAttribute)) != null)
            {
                return ((SchemaAttribute)type.GetCustomAttribute(typeof(SchemaAttribute))).Name;
            }
            else
            {
                return null;
            }
        }

        protected string GetTableFullName(Type type = null)
        {
            if (type == null)
            {
                type = typeof(T);
            }
            if (type != null)
            {
                string schemaName = ((SchemaAttribute)type.GetCustomAttribute(typeof(SchemaAttribute)))?.Name;
                string tableName = ((TableNameAttribute)type.GetCustomAttribute(typeof(TableNameAttribute)))?.Name;
                return !string.IsNullOrEmpty(schemaName) && !string.IsNullOrEmpty(tableName) ? " [" + schemaName + "].[" + tableName + "] "
                    : !string.IsNullOrEmpty(tableName) ? tableName : null;
            }
            else
            {
                return null;
            }
        }

        protected ISqlDialect GetDbDialect()
        {
            EnsureDbHelper();
            return DbDialect;
        }

        protected ManagedSQLRepositoryBase()
        {
        }

        protected K InsertNew(T entity, bool reConfig = false)
        {
            EnsureConfig();
            if (reConfig)
            {
                ReConfig(entity);
            }
            PrepareForInsert(entity);
            return PerformInsert(entity);
        }

        protected void InsertEntities(IEnumerable<T> entities)
        {
            EnsureConfig();
            entities.ForEach(entity => PrepareForInsert(entity));
            PerformInserts(entities);
        }

        public dynamic ExecuteProcedure(string storedprocName,DynamicParameters param)
        {
            EnsureConfig();
            IDbConnection con = GetConnection();
            if (con.State == ConnectionState.Closed)
                con.Open();
            con.Execute(storedprocName, param, commandType: CommandType.StoredProcedure, commandTimeout: 120);
            return param.Get<dynamic>("@Result");
        }
        protected bool InsertUpdate(T entity)
        {
            EnsureConfig();
            PrepareForUpdate(entity);
            return PerformUpdate(entity);
        }

        protected bool Delete(K id)
        {
            EnsureConfig();
            return PerformDelete(Get(id));
        }

        protected bool Delete(T entity)
        {
            EnsureConfig();
            return PerformDelete(entity);
        }

        protected bool Delete(Expression<Func<T, bool>> predicate)
        {
            EnsureConfig();
            return repository.Delete(predicate);
        }

        protected T Get(K id)
        {
            EnsureConfig();
            if (typeof(K) == typeof(int) || typeof(K) == typeof(long))
            {
                return repository.Get(Convert.ToInt32(id));
            }
            else if (typeof(K) == typeof(Guid))
            {
                return repository.Get(Guid.Parse(id.ToString()));
            }
            else if (typeof(K) == typeof(string))
            {
                return repository.Get(id.ToString());
            }
            else
            {
                return default(T);
            }
        }

        protected IQueryable<T> GetAll()
        {
            EnsureConfig();
            return repository.GetList().AsQueryable<T>();
        }

        protected IEnumerable<T> Find(Expression<Func<T, bool>> predicate)
        {
            EnsureConfig();
            return repository.Query(predicate).AsEnumerable();
        }

        protected IEnumerable<T> Find(Expression<Func<T, bool>>[] predicates)
        {
            EnsureConfig();
            List<T> entites = new List<T>();
            foreach (Expression<Func<T, bool>> predicate in predicates)
            {
                entites.AddRange(Find(predicate));
            }
            return entites;
        }

        protected IEnumerable<T> Query(string sql, object parameter = null)
        {
            EnsureConfig();
            return repository.Query(sql, parameter);
        }

        protected object QueryScalar(string sql, object parameter = null)
        {
            EnsureConfig();
            return repository.QueryScalar(sql, parameter);
        }

        protected L QueryScalar<L>(string sql, object parameter = null)
        {
            EnsureConfig();
            return (L)Convert.ChangeType(repository.QueryScalar(sql, parameter), typeof(L));
        }

        protected IEnumerable<R> Query<R>(string sql, object parameter = null)
        {
            EnsureConfig();
            CommandDefinition comm = new CommandDefinition(sql, ((parameter != null) ? new DynamicParameters(parameter) : null), commandType: CommandType.Text);
            return GetConnection().Query<R>(comm);
        }

        protected IEnumerable<R> ExecuteProcedure<R>(string procedureName, object parameter = null)
        {
            EnsureConfig();
            CommandDefinition comm = new CommandDefinition(procedureName, ((parameter != null) ? new DynamicParameters(parameter) : null), commandType: CommandType.StoredProcedure);
            return GetConnection().Query<R>(comm);
        }

        protected long Count(Expression<Func<T, bool>> predicate = null)
        {
            EnsureConfig();
            return repository.Count(predicate);
        }

        protected V GetRecord<V>(long recordId)
            where V : class, IEntity, new()
        {
            EnsureConfig();
            DapperCustomRepository<V> recordRepository = new DapperCustomRepository<V>(GetOrCreateSessionContext<V>());
            V record = recordRepository.Get((int)recordId);
            return record;
        }

        protected int Execute(string sql, object parameter = null)
        {
            EnsureConfig();
            CommandDefinition comm = new CommandDefinition(sql, ((parameter != null) ? new DynamicParameters(parameter) : null), commandType: CommandType.Text);
            return GetConnection().Execute(comm);
        }

        protected void Truncate()
        {
            EnsureConfig();
            GetConnection().Execute("TRUNCATE TABLE " + GetTableFullName());
        }

        public void InsertUpdate(IEnumerable<T> entities)
        {
            EnsureConfig();
            IPredicate predicate = GetKeyPredicate(config.GetMap<T>());
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            string sql = GetSqlGenerator().Update(config.GetMap<T>(), predicate, parameters);
            foreach (KeyValuePair<string, object> parameter in parameters)
            {
                sql = sql.Replace(parameter.Key, parameter.Value.ToString());
            }
            entities.ForEach(x => PrepareForUpdate(x));
            GetConnection().Execute(sql, entities);
        }
        
        public void Dispose()
        {
            if (config != null && repository != null && GetConnection() != null && GetConnection().State == ConnectionState.Open)
            {
                GetConnection().Close();
            }
        }
    }
}
