﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Collections.Concurrent;
using System.Diagnostics;

namespace Cat.Apps.Terra.AppFramework.Patterns.Memory
{
    public abstract class RefreshingCacheItemAccessBase<T> : RefreshingCacheItemAccessBase
    {
        private static ConcurrentDictionary<Type, ConcurrentDictionary<string, T>> m_SourceItemsOnHand = new ConcurrentDictionary<Type, ConcurrentDictionary<string, T>>();

        private static ConcurrentDictionary<Type, List<string>> m_SourceKnownIds = new ConcurrentDictionary<Type, List<string>>();

        private ConcurrentDictionary<string, T> m_ItemsOnHand
        {
            get { return m_SourceItemsOnHand[this.GetType()]; }
        }

        private List<string> m_KnownIds
        {
            get { return m_SourceKnownIds[this.GetType()]; }
        }

        protected RefreshingCacheItemAccessBase()
        {
            m_SourceKnownIds.TryAdd(this.GetType(), new List<string>());
            m_SourceItemsOnHand.TryAdd(this.GetType(), new ConcurrentDictionary<string, T>());
        }

        protected override void PerformRefresh()
        {
            Tuple<string, T>[] items = ObtainAllItemsFromSource();
            foreach (Tuple<string, T> item in items)
            {
                m_ItemsOnHand.AddOrUpdate(item.Item1, item.Item2, (k, v) => item.Item2);
            }
        }

        protected T GetItem(string id)
        {
            T item = m_ItemsOnHand.Keys.Contains(id) ? m_ItemsOnHand[id] : m_ItemsOnHand.GetOrAdd(id, PerformObtain(id));
            return item;
        }

        private T PerformObtain(string id)
        {
            lock (m_KnownIds)
            {
                if (m_KnownIds.Contains(id) == false)
                {
                    m_KnownIds.Add(id);
                }
            }
            return ObtainItemFromSource(id);
        }

        protected abstract T ObtainItemFromSource(string id);

        private Tuple<string, T>[] ObtainAllItemsFromSource()
        {
            string[] ids = m_KnownIds.ToArray();
            List<Tuple<string, T>> items = new List<Tuple<string, T>>();
            foreach (string id in ids)
            {
                T item = ObtainItemFromSource(id);
                items.Add(new Tuple<string, T>(id, item));
            }
            return items.ToArray();
        }
    }

    public abstract class RefreshingCacheItemAccessBase
    {
        private static Thread m_ExpireThread;
        private static ManualResetEvent m_WaitReset = new ManualResetEvent(false);
        private static TimeSpan m_RefreshInterval = new TimeSpan(1, 0, 0);

        private static ConcurrentDictionary<Type, RefreshingCacheItemAccessBase> m_RegisteredInstanceTypes =
            new ConcurrentDictionary<Type, RefreshingCacheItemAccessBase>();

        static RefreshingCacheItemAccessBase()
        {
            m_ExpireThread = new Thread(RefreshOnGoing);
            m_ExpireThread.Start();
        }

        internal RefreshingCacheItemAccessBase()
        {
            EnsureRegistration();
        }

        private void EnsureRegistration()
        {
            m_RegisteredInstanceTypes.TryAdd(this.GetType(), this);
        }

        protected abstract void PerformRefresh();

        private static void RefreshOnGoing()
        {
            for (; ; )
            {
                IEnumerable<RefreshingCacheItemAccessBase> items = m_RegisteredInstanceTypes.Values;
                foreach (RefreshingCacheItemAccessBase item in items)
                {
                    try
                    {
                        item.PerformRefresh();
                    }
                    catch (Exception ex)
                    {
                        Trace.TraceError("An attempt to refresh the cache in " +
                                         item.GetType().Name + " failed with error: '" +
                                         ex.Message + "'");
                    }
                }
                m_WaitReset.WaitOne(m_RefreshInterval);
            }
        }
    }
}
