﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cat.Apps.Terra.AppFramework
{
   public interface IManagedIdentityRepository<I, T> : IRepositoryBase<I, T>
    {
        I Insert(T entity);
        void Update(T entity);
        
    }
}
