﻿using System.Diagnostics.CodeAnalysis;

namespace Cat.Terra.WOA.Entities.ViewModels
{
    /// <summary>
    /// AssignedAsset View model
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AssignedAsset
    {
        /// <summary>
        /// Make
        /// </summary>
        public string Make { get; set; }
        /// <summary>
        /// SerialNumber
        /// </summary>
        public string SerialNumber { get; set; }
    }
}
