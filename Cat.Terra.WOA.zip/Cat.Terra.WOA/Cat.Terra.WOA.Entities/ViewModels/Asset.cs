﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Cat.Terra.WOA.Entities.ViewModels
{
    [ExcludeFromCodeCoverage]
    public class Asset
    {
        /// <summary>
        /// Asset Model
        /// </summary>
        public string Model { get; set; }
        /// <summary>
        /// Make
        /// </summary>
        public string Make { get; set; }
        /// <summary>
        /// SerialNumber
        /// </summary>
        public string SerialNumber { get; set; }
        /// <summary>
        /// List of Site Id's
        /// </summary>
        public IEnumerable<int> Sites { get; set; }
    }
}
