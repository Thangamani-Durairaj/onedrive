﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Cat.Terra.WOA.Entities.ViewModels
{
    [ExcludeFromCodeCoverage]
    public class Job 
    {
        /// <summary>
        /// SiteId
        /// </summary>
        public int? SiteId { get; set; }
        /// <summary>
        /// SiteName
        /// </summary>
        public string SiteName { get; set; }
        /// <summary>
        /// JobState
        /// </summary>
        public string JobState { get; set; }
        /// <summary>
        /// ReadyDateTime
        /// </summary>
        public DateTime? ReadyDateTime { get; set; }
        /// <summary>
        /// StartDoingDateTime
        /// </summary>
        public DateTime? StartDoingDateTime { get; set; }
        /// <summary>
        /// StopDoingDateTime
        /// </summary>
        public DateTime? StopDoingDateTime { get; set; }
        /// <summary>
        /// DoneDateTime
        /// </summary>
        public DateTime? DoneDateTime { get; set; }
        /// <summary>
        /// DoneReason
        /// </summary>
        public string DoneReason { get; set; }
        /// <summary>
        /// ZoneName
        /// </summary>
        public string ZoneName { get; set; }
        /// <summary>
        /// TargetMaterialWeight
        /// </summary>
        public double? TargetMaterialWeight { get; set; }
        /// <summary>
        /// LoaderPassCount
        /// </summary>
        public int? LoaderPassCount { get; set; }
        /// <summary>
        /// TruckCode
        /// </summary>
        public string TruckCode { get; set; }
        /// <summary>
        /// TruckName
        /// </summary>
        public string TruckName { get; set; }
        /// <summary>
        /// MaterialCode
        /// </summary>
        public string MaterialCode { get; set; }
        /// <summary>
        /// MaterialName
        /// </summary>
        public string MaterialName { get; set; }
        /// <summary>
        /// LoaderCode
        /// </summary>
        public string LoaderCode { get; set; }
        /// <summary>
        /// LoaderName
        /// </summary>
        public string LoaderName { get; set; }
        /// <summary>
        /// TimeOnSite
        /// </summary>
        public string TimeOnSite { get; set; }
        /// <summary>
        /// TimeBeforeLoaded
        /// </summary>
        public string TimeBeforeLoaded { get; set; }
        /// <summary>
        /// TimeAfterLoaded
        /// </summary>
        public string TimeAfterLoaded { get; set; }
 
    }

}
