﻿using Cat.Apps.Terra.SQLFramework.Data.SQL;
using Cat.Apps.Terra.SQLFramework.Data.SQL.Attributes;
using System;

namespace Cat.Terra.WOA.Entities
{
    public class Job : ManagedTableEntity
    {
        [Key]
        public long JobId { get; set; }
        public string Origin { get; set; }
        public Int32 JobState { get; set; }
        public DateTime? ReadyDateTime { get; set; }
        public DateTime? StartDoingDateTime { get; set; }
        public DateTime? StopDoingDateTime { get; set; }
        public DateTime? DoneDateTime { get; set; }
        public string DoneReason { get; set; }
        public int? ZoneId { get; set; }
        public string ZoneCode { get; set; }
        public string ZoneName { get; set; }
        public int SiteId { get; set; }
        public Int64? TruckId { get; set; }
        public string TruckCode { get; set; }
        public string TruckName { get; set; }
        public int? MaterialId { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialName { get; set; }
        public string UCID { get; set; }
        public double? TargetMaterialWeight { get; set; }
        public int? LoaderID { get; set; }
        public string LoaderCode { get; set; }
        public string LoaderName { get; set; }
        public int? LoaderPassCount { get; set; }
        public double? LoaderMaterialWeight { get; set; }
        public bool? IsLoaded { get; set; }
        public string TimeOnSite { get; set; }
        public string TimeBeforeLoaded { get; set; }
        public string TimeAfterLoaded { get; set; }
        public int TotalRecords { get; set; }
        public long JobHash { get; set; }
    }
}
