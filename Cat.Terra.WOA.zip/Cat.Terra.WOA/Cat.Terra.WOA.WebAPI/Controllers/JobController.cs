﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Cat.Terra.WOA.Entities;
using Cat.Terra.WOA.Services;

namespace Cat.Terra.WOA.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/sites")]
    public class JobController : BaseController
    {
        private IJobService _JobService;

        public JobController(IJobService JobService)
        {
            _JobService = JobService;
        }

        public async Task<IActionResult> GetJobsAsync([FromQuery]JobRequest request)
        {
            string ucid = GetUcid();
            int siteId = 0;

            if (Enforce(ucid, siteId))
            {
                return BadRequest("Invalid UCID or SiteID");
            }
            else
            {
                var jobsList = await _JobService.GetJobsAsync(request);
                return Ok();
            }
        }
    }
}
