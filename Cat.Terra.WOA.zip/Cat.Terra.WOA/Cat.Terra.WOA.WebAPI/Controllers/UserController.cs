﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Cat.Terra.WOA.Entities;
using Cat.Terra.WOA.Services;

namespace Cat.Terra.WOA.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/sites")]
    public class UserController : BaseController
    {
        public async Task<IActionResult> GetUsers()
        {
            await Task.Delay(10);
            return Ok();
        }
    }
}
