﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Cat.Terra.WOA.Entities;
using Cat.Terra.WOA.Services;

namespace Cat.Terra.WOA.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/sites")]
    public class AssetController : BaseController
    {
        public async Task<IActionResult> GetAssets([FromQuery]AssetRequest request)
        {
            return null;
        }

        public async Task<IActionResult> GetAssignedAssets(int siteId, string ucid = null)
        {
            return null;
        }
    }
}
