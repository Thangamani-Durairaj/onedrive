﻿using Cat.Apps.Terra.AppFramework;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Cat.Apps.Terra.CloudFramework
{
    public abstract class ManagedRepositoryBase<TRepository, T, S> where TRepository : ManagedRepositoryBase<TRepository, T, S>
                                                                   where S : IStorageClientBuilder, new()
                                                                   where T : ITableEntity
    {
        private CloudTableClient m_TableClient;
        private static string m_TableName;
        private const int BATCH_LIMIT = 100;
        private const int QUERY_BATCH_MAX = 5;
        private const int MAX_QUERY_RESULTS = 10000;
        private const int QUERY_TIMEOUT_SECONDS = 12000;
        protected abstract string GetTableName();
       public ManagedRepositoryBase()
        {
            EnsureTable();
            m_TableClient = CreateTableClient();
        }
        private void EnsureTable()
        {
            if (m_TableName.IsNullOrEmpty())
            {
                HydrateTable(GetTableName());
            }
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        private static void HydrateTable(string tableName)
        {
            if (m_TableName.IsNullOrEmpty())
            {
                m_TableName = tableName;
                EnsureTableExists(m_TableName);
            }
            else
            {
                if (m_TableName != tableName)
                {
                    throw new InvalidOperationException("Current table name is '" + m_TableName +
                                                        "' but it changed to '" + tableName +
                                                        ".'  It must remain constant.");
                }
            }
        }
        private static void EnsureTableExists(string tableName)
        {
            CloudTableClient client = CreateTableClient();
            CloudTable table = client.GetTableReference(tableName);
            table.CreateIfNotExistsAsync();
        }
        private void EnforceGoodKey(ITableEntity entity)
        {
            string error = string.Empty;
            if (entity.RowKey.IsNullOrEmpty())
            {
                error = "Row Key ";
            }

            if (entity.PartitionKey.IsNullOrEmpty())
            {
                if (error.IsNullOrEmpty())
                {
                    error = "Partition Key is ";
                }
                else
                {
                    error += " & Partition Key are ";
                }
            }
            if (error.IsNullOrEmpty() == false)
            {
                error += "missing.";
                throw new InvalidOperationException(error);
            }
        }
        protected static CloudTableClient CreateTableClient()
        {
            return new S().BuildTableClient();
        }
        private void PerformInsert(T entity)
        {
            CloudTable table = m_TableClient.GetTableReference(m_TableName);
            TableOperation insertOperation = TableOperation.Insert(entity);
            table.ExecuteAsync(insertOperation);
        }
        private void PerformInsertUpdate(T entity)
        {
            CloudTable table = m_TableClient.GetTableReference(m_TableName);
            TableOperation insertOperation = TableOperation.InsertOrMerge(entity);
            table.ExecuteAsync(insertOperation);
        }
        private IEnumerable<R> PerformRefinedSearch<R>(Expression<Func<R, bool>> predicate) where R : T, new()
        {
            CloudTable table = m_TableClient.GetTableReference(m_TableName);
            //Ignore any inactive rows.  They are considered deleted.
            //Exclude historical rows, they are old
            //Exclude uncommited rows unless they were inserted under the current transaction id
            TableQuery<R> query = table.CreateQuery<R>().Where(predicate) as TableQuery<R>;
         //   query.TakeCount = MAX_QUERY_RESULTS;
            TimeSpan timeout = TimeSpan.FromSeconds(QUERY_TIMEOUT_SECONDS);
            TableRequestOptions options = new TableRequestOptions() { ServerTimeout = timeout, MaximumExecutionTime = timeout };
            IEnumerable<R> results = table.ExecuteQuery(query, options);
            return results;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected void InsertNew(T entity)
        {
            EnforceGoodKey(entity);
            PerformInsert(entity);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected void InsertUpdate(T entity)
        {
            EnforceGoodKey(entity);
            PerformInsertUpdate(entity);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected R RetrieveSpecific<R>(TableKey key) where R : T, new()
        {
            return RetrieveSpecific<R>(key, new string[] { });
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected R RetrieveSpecific<R>(TableKey key, string[] alternatePartitionKeys) where R : T, new()
        {
            try
            {
                EnforceGoodKey(key.AsTableEntity());
                CloudTable table = m_TableClient.GetTableReference(m_TableName);
                TableQuery<R> query = table.CreateQuery<R>().Where(Row => Row.PartitionKey == key.PartitionKey && Row.RowKey == key.RowKey) as TableQuery<R>;
                return table.ExecuteQuery(query).FirstOrDefault();
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected R[] Find<R>(Expression<Func<R, bool>> predicate) where R : T, new()
        {
            R[] entities = PerformFind<R>(predicate);
            return entities;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        protected R[] Find<R>(Expression<Func<R, bool>>[] predicates, bool multiplex = false) where R : T, new()
        {
            R[] entities = PerformFindBatch<R>(predicates, multiplex);
            IEnumerable<ITableEntity> tableEntities = entities.Cast<ITableEntity>();
            entities = entities.Cast<R>().ToArray();
            return entities;
        }

        private R[] PerformFind<R>(Expression<Func<R, bool>> predicate) where R : T, new()
        {
            R[] entities = PerformRefinedSearch(predicate).ToArray();
            return entities;
        }

        private R[] PerformFindBatch<R>(Expression<Func<R, bool>>[] predicates, bool multiplex) where R : T, new()
        {
            int concurrentLimit = 1;
            if (predicates.IsNullOrEmpty())
            {
                throw new InvalidOperationException("No predicates were provided to the table query.");
            }
            if (multiplex)
            {
                concurrentLimit = QUERY_BATCH_MAX;
            }
            List<R> entities = new List<R>();
            Semaphore throttle = new Semaphore(concurrentLimit, concurrentLimit);
            ManualResetEvent allDone = new ManualResetEvent(false);
            int completionCount = 0;
            foreach (Expression<Func<R, bool>> predicate in predicates)
            {
                throttle.WaitOne();
                WaitCallback fire = delegate
                {
                    try
                    {
                        lock (entities)
                        {
                            entities.AddRange(PerformFind<R>(predicate));
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.TraceError(this.GetType().Name + " encountered an exception when trying to execute a find operation against table storage for table: " + m_TableName + ".  Error reads: " + ex.Message);
                    }
                    finally
                    {
                        throttle.Release();
                        Interlocked.Increment(ref completionCount);
                        if (completionCount == predicates.Length)
                        {
                            allDone.Set();
                        }
                    }
                };
                ThreadPool.QueueUserWorkItem(fire);
            }
            int timeOutSeconds = QUERY_TIMEOUT_SECONDS + 5;
            bool signaledInTime = allDone.WaitOne(TimeSpan.FromSeconds(timeOutSeconds));
            if (signaledInTime == false)
            {
                Trace.TraceError("One or more queries timed out within the specified timeout of " + timeOutSeconds + " seconds.  The batch size was " + predicates.Length + " on table '" + m_TableName + ".'  " + entities.Count + " were returned regardless.");

            }
            return entities.ToArray();
        }
    }
}
