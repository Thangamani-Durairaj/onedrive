﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cat.Apps.Terra.CloudFramework
{
    public class TableKey
    {
        public TableKey()
        { }
        public TableKey(ITableEntity inputEntity)
        {
            PartitionKey = inputEntity.PartitionKey;
            RowKey = inputEntity.RowKey;
        }
        public virtual string PartitionKey { get; set; }
        public virtual string RowKey { get; set; }

        public override bool Equals(object obj)
        {
            TableKey comparing = obj as TableKey;
            return PartitionKey == comparing.PartitionKey && RowKey == comparing.RowKey;
        }
        public override int GetHashCode()
        {
            return PartitionKey.GetHashCode() ^ RowKey.GetHashCode();
        }

        public override string ToString()
        {
            return "Partition: " + PartitionKey + ", Row: " + RowKey;
        }

        public ITableEntity AsTableEntity()
        {
            return new TableEntity() { PartitionKey = PartitionKey, RowKey = RowKey };
        }
    }
}
