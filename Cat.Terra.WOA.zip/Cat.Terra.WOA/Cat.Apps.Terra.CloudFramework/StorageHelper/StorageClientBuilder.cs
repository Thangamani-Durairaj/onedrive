﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Apps.Terra.CloudFramework
{
   public class StorageClientBuilder : IStorageClientBuilder
    {
        CloudStorageAccount m_Account = null;

        public StorageClientBuilder()
        { }

        private void EnsureStorageAccount()
        {
            if (m_Account == null)
            {
                m_Account = StorageAccountHelper.CreateAccount();
            }
        }

        CloudTableClient IStorageClientBuilder.BuildTableClient()
        {
            EnsureStorageAccount();
            return m_Account.CreateCloudTableClient();
        }
    }
}
