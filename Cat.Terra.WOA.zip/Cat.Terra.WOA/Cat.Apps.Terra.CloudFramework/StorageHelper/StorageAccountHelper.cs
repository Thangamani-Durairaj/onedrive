﻿//using Cat.Apps.Terra.Util.Common;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Configuration;

namespace Cat.Apps.Terra.CloudFramework
{
    internal static class StorageAccountHelper
    {
        private static void EnforceSettingPresent(string connectionString)
        {
            if (connectionString == default(string))
            {
                throw new InvalidProgramException("CoreDataConnectionString must be provided to the local settings manager to connect to the Forms Definitions Database.");
            }
        }

        public static CloudStorageAccount CreateAccount()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["StorageAccount"].ConnectionString;
            EnforceSettingPresent(connectionString);

            //Helper.ConstructStorageAccountConnectionString(connectionString)
            CloudStorageAccount account = CloudStorageAccount.Parse("");
            return account;
        }
    }
}
