﻿using System;

namespace Cat.Terra.WOA.DA
{
    public interface IAssetsDA
    {
    }
}
