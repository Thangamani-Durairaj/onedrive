﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Cat.Apps.Terra.AppFramework;
using Cat.Apps.Terra.SQLFramework;
using Cat.Apps.Terra.SQLFramework.Data.SQL;
using Cat.Terra.WOA.Entities;

namespace Cat.Terra.WOA.DA
{
    public class JobRepository : ManagedSQLRepositoryBase<JobRepository, Job, SqlDbConnectionBuilder, int>, IJobsRepository
    {
        void IRepositoryBase<int, Job>.Delete(int identity)
        {
            throw new NotImplementedException();
        }

        R[] IRepositoryBase<int, Job>.Find<R>(Expression<Func<R, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        R[] IRepositoryBase<int, Job>.Find<R>(Expression<Func<R, bool>>[] predicates)
        {
            throw new NotImplementedException();
        }

        Job[] IRepositoryBase<int, Job>.Find(Expression<Func<Job, bool>> predicate)
        {
            return Find(predicate).ToArray();
        }

        Job[] IRepositoryBase<int, Job>.Find(Expression<Func<Job, bool>>[] predicates)
        {
            return Find(predicates).ToArray();
        }

        Job IRepositoryBase<int, Job>.Get(int identity)
        {
            throw new NotImplementedException();
        }

        R IRepositoryBase<int, Job>.Get<R>(int identity)
        {
            throw new NotImplementedException();
        }

        IQueryable<Job> IRepositoryBase<int, Job>.GetAll()
        {
            throw new NotImplementedException();
        }

        IQueryable<R> IRepositoryBase<int, Job>.GetAll<R>()
        {
            throw new NotImplementedException();
        }

        int IManagedIdentityRepository<int, Job>.Insert(Job entity)
        {
            return InsertNew(entity);
        }

        void IManagedIdentityRepository<int, Job>.Update(Job entity)
        {
            InsertUpdate(entity);
        }

        Job[] IJobsRepository.ListJobs(Int32[] SiteID)
        {
            //Define Fields to select
            string Fields = $"DoneReason,IsLoaded,JobId,JobState,LoaderCode,LoaderId,LoaderMaterialWeight,LoaderName,LoaderPassCount,MaterialCode,MaterialId,MaterialName,";
            Fields = $"{Fields}Origin,ReadyDateTime,SiteId,StartDoingDateTime,StopDoingDateTime,TargetMaterialWeight,TimeAfterLoaded,TimeBeforeLoaded,TimeOnSite,TotalRecords,";
            Fields = $"{Fields}TruckCode,TruckId,TruckName,UCID,ZoneCode,ZoneId,ZoneName,DoneDateTime,JobHash,CreatedBy,CreatedDateTime,ModifiedBy,ModifiedDateTime";

            StringBuilder Query = new StringBuilder();
            ///Create Temp Table
            Query.Append("DECLARE @Job TABLE([DoneReason] [nvarchar] (20) NULL, [IsLoaded] [bit] NULL,[JobId] [bigint]  NOT NULL,[JobState] [nvarchar] (20) NULL,");
            Query.Append("[LoaderCode] [nvarchar] (50)  NULL,[LoaderId] [int]  NULL,[LoaderMaterialWeight] [float]  NULL,[LoaderName] [nvarchar] (50)  NULL,[LoaderPassCount] [int]  NULL,");
            Query.Append("[MaterialCode] [nvarchar] (50)  NULL,[MaterialId] [int]  NULL,[MaterialName] [nvarchar] (50)  NULL,[Origin] [nvarchar] (20)  NULL,[ReadyDateTime] [datetime2] (7)  NULL,");
            Query.Append("[SiteId] [int] not NULL,[StartDoingDateTime] [datetime2] (7)  NULL,[StopDoingDateTime] [datetime2] (7)  NULL,");
            Query.Append("[TargetMaterialWeight] [float] NULL,[TimeAfterLoaded] [nvarchar] (50)  NULL,[TimeBeforeLoaded] [nvarchar] (50)  NULL,[TimeOnSite] [nvarchar] (50)  NULL,");
            Query.Append("[TotalRecords] [int] NOT NULL,[TruckCode] [nvarchar] (50)  NULL,[TruckId] [int]  NULL,[TruckName] [nvarchar] (50)  NULL,[UCID] [nvarchar] (50)  NULL,");
            Query.Append("[ZoneCode] [nvarchar] (50)  NULL,[ZoneId] [int]  NULL,[ZoneName] [nvarchar] (500)  NULL,[DoneDateTime] [datetime2] (7) NULL,CreatedDateTime datetime,");
            Query.Append("ModifiedDateTime datetime,[CreatedBy] [nvarchar] (50)  NULL,[ModifiedBy] [nvarchar] (50),JobHash [bigint])");

            string Jobstatus_todo = Enum.GetName(typeof(JobStatus), JobStatus.todo);
            string Jobstatus_doingnotloaded = Enum.GetName(typeof(JobStatus), JobStatus.doingnotloaded);
            ///Construct query againts Site
            for (int index = 0; index < SiteID.Length; index++)
            {
                Query.AppendFormat(" insert into @Job({0}) select top 250 {1} from Job where siteid={2} and ReadyDateTime <='{3}' and (jobstate ='{4}' or jobstate='{5}')    order by ReadyDateTime asc ", Fields, Fields, SiteID[index], DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss"), (int)JobStatus.todo, (int)JobStatus.doingnotloaded);
            }
            Query.AppendFormat(" select {0} from @Job", Fields);
            return Query<Job>(Query.ToString()).ToArray();
        }

        void IJobsRepository.Update(string Query, object entity)
        {
            Execute(Query, entity);
        }
    }
}
