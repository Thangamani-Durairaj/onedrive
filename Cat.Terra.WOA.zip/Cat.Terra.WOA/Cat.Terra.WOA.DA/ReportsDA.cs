﻿using System;

namespace Cat.Terra.WOA.DA
{
    public class ReportsDA
    {
    }
}
